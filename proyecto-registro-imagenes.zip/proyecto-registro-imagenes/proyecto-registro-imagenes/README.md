# Proyecto: Registro de Imágenes y Medición

**Asignatura:** Visión por Computador (2025-02) — Trabajo 2  
**Autor:** Equipo (adaptar según integrantes)  
**Fecha de generación:** 2025-11-03 01:29:14 UTC

## Estructura del repositorio
```
proyecto-registro-imagenes/
├── README.md
├── requirements.txt
├── data/
│   ├── original/        # Imágenes del comedor (3 imágenes generadas sintéticamente)
│   └── synthetic/       # Imágenes para validación con transformaciones conocidas
├── src/
│   ├── feature_detection.py
│   ├── matching.py
│   ├── registration.py
│   ├── measurement.py
│   └── utils.py
├── notebooks/
│   ├── 01_exploratory_analysis.ipynb
│   ├── 02_synthetic_validation.ipynb
│   └── 03_main_pipeline.ipynb
├── results/
│   ├── figures/
│   └── measurements/
└── tests/
```
## Objetivo
Proveer una solución modular y reproducible para:
- validar el pipeline de registro con imágenes sintéticas (ground truth)
- registrar y fusionar 3 vistas del comedor
- calibrar la escala métrica usando objetos de referencia (cuadro: 117 cm, mesa: 161.1 cm)
- medir otros objetos en la escena

## Cómo ejecutar
1. Crear un entorno virtual e instalar dependencias:
```bash
python -m venv venv
source venv/bin/activate  # o venv\Scripts\activate en Windows
pip install -r requirements.txt
```
2. Abrir los notebooks en `notebooks/` y ejecutar las celdas en orden.
3. Los scripts principales están en `src/` y pueden ejecutarse desde Python o importarse en los notebooks.

---
